#include "Engine.h"
#include <stdlib.h>
#include <math.h>
#include <memory.h>

//
//  You are free to modify this file
//

//  is_key_pressed(int button_vk_code) - check if a key is pressed,
//                                       use keycodes (VK_SPACE, VK_RIGHT, VK_LEFT, VK_UP, VK_DOWN, 'A', 'B')
//
//  get_cursor_x(), get_cursor_y() - get mouse cursor position
//  is_mouse_button_pressed(int button) - check if mouse button is pressed (0 - left button, 1 - right button)
//  clear_buffer() - set all pixels in buffer to 'black'
//  is_window_active() - returns true if window is active
//  schedule_quit_game() - quit game after act()


#define ASSERT(COND) if (COND) {} else { __debugbreak(); } void(0)
#define ARRAY_COUNT(ARRAY) (sizeof(ARRAY) / sizeof((ARRAY)[0]))


float uniform_real(float from, float to)
{
    ASSERT(to > from);

    float r = float(rand()) / float(RAND_MAX / to); // Uniform [0, to]
    return r + from;
}


float min(float x, float y)
{
    return (x < y) ? x : y;
}


float max(float x, float y)
{
    return (x < y) ? y : x;
}


float sign(float value)
{
    float result = (float)((value > 0) - (value < 0));
    return result;
}


int32_t truncate_to_int32(float x)
{
    int32_t result = (int32_t) x;
    return result;
}


int32_t round_to_int32(float x)
{
    float result = x + 0.5f * sign(x);
    return (int32_t) result;
}


struct v2
{
    float x, y;
};


v2 operator * (float c, v2 v)
{
    v2 result = { c * v.x, c * v.y };
    return result;
}


v2 operator * (v2 v, float c)
{
    v2 result = (c * v);
    return result;
}


v2 operator + (v2 left, v2 right)
{
    v2 result = { left.x + right.x, left.y + right.y };
    return result;
}


v2 operator - (v2 left, v2 right)
{
    v2 result = { left.x - right.x, left.y - right.y };
    return result;
}


float dot(v2 left, v2 right)
{
    float result = left.x * right.x + left.y * right.y;
    return result;
}


float length_squared(v2 v)
{
    float result = dot(v, v);
    return result;
}


float length(v2 v)
{
    float result = sqrtf(length_squared(v));
    return result;
}


v2 normalized(v2 v)
{
    float n = length(v);
    v2 result = { v.x / n, v.y / n };
    return result;
}


union v4
{
    struct { float x, y, z, w; };
    struct { float r, g, b, a; };

    static const v4 black;
    static const v4 white;
    static const v4 red;
    static const v4 green;
    static const v4 blue;
};

const v4 v4::black = { 0.0f, 0.0f, 0.0f, 1.0f };
const v4 v4::white = { 1.0f, 1.0f, 1.0f, 1.0f };
const v4 v4::red   = { 1.0f, 0.0f, 0.0f, 1.0f };
const v4 v4::green = { 0.0f, 1.0f, 0.0f, 1.0f };
const v4 v4::blue  = { 0.0f, 0.0f, 1.0f, 1.0f };


v4 operator * (float c, v4 v)
{
    v4 result = { c * v.x, c * v.y, c * v.z, c * v.w };
    return result;
}


v4 operator * (v4 v, float c)
{
    v4 result = (c * v);
    return result;
}


v4 operator + (v4 left, v4 right)
{
    v4 result = { left.x + right.x, left.y + right.y, left.z + right.z, left.w + right.w };
    return result;
}


v4 operator - (v4 left, v4 right)
{
    v4 result = { left.x - right.x, left.y - right.y, left.z - right.z, left.w - right.w };
    return result;
}


uint32_t pack(v4 color)
{
    // Memory order (little-endian): BGRA
    uint32_t result = ((uint32_t)(color.a * 255.0f) << 24)
                    | ((uint32_t)(color.r * 255.0f) << 16) // RED
                    | ((uint32_t)(color.g * 255.0f) << 8) // GREEN
                    | ((uint32_t)(color.b * 255.0f)); // BLUE

    return result;
}


struct rect2
{
    v2 min;
    v2 max;
};


rect2 from_center_half_dim(v2 center, v2 half_dim)
{
    rect2 result;
    result.min = center - half_dim;
    result.max = center + half_dim;
    return result;
}


rect2 from_center_dim(v2 center, v2 dimensions)
{
    rect2 result = from_center_half_dim(center, 0.5f * dimensions);
    return result;
}


bool in_rectangle(rect2 r, v2 v)
{
    bool result = r.min.x < v.x && v.x < r.max.x
               && r.min.y < v.y && v.y < r.max.y;
    return result;
}


enum EntityType
{
    ENTITY_TYPE_NULL,
    ENTITY_TYPE_PLAYER,
    ENTITY_TYPE_TARGET,
    ENTITY_TYPE_BALL,
};


static const float PLAYER_VELOCITY_COEFF = 400.0f;
static const float BALL_VELOCITY_COEFF = 300.0f;

struct Entity
{
    EntityType type;
    v2 p;
    v2 v;

    int32_t width;
    int32_t height;
    v4 color;
    bool dead;
};


struct GameState
{
    Entity entities[64];
    size_t entity_count;

    int32_t player_id;
    int32_t current_ball_id;

    int32_t target_count;
    int32_t score;
    
    bool running;
    bool ended;
};
static GameState global_game_state;


uint32_t push_entity(GameState *gs, Entity e)
{
    ASSERT(gs->entity_count < ARRAY_COUNT(gs->entities));

    uint32_t result = 0;
    if (gs->entity_count < ARRAY_COUNT(gs->entities))
    {
        result = gs->entity_count;
        gs->entities[gs->entity_count++] = e;
    }
    return result;
}


Entity *get_entity(GameState *gs, uint32_t index)
{
    ASSERT(index < ARRAY_COUNT(gs->entities));

    Entity *result = 0;
    if (index < gs->entity_count)
    {
        result = gs->entities + index;
    }

    return result;
}


uint32_t push_player(GameState* gs, int32_t width, int32_t height)
{
    v2 p = { 0.5f * SCREEN_WIDTH, SCREEN_HEIGHT - 0.5f * height };

    Entity player = {};
    player.type = ENTITY_TYPE_PLAYER;
    player.p = p;
    player.width = width;
    player.height = height;
    player.color = v4::white;

    return push_entity(gs, player);
}


uint32_t push_ball(GameState* gs, v2 p)
{
    Entity ball = {};
    ball.type = ENTITY_TYPE_BALL;
    ball.p = p;
    ball.width = 20;
    ball.height = 20;
    ball.color = v4::white;

    return push_entity(gs, ball);
}


void draw_rect(rect2 r, v4 color)
{
    int32_t min_x = round_to_int32(r.min.x);
    int32_t min_y = round_to_int32(r.min.y);

    int32_t max_x = round_to_int32(r.max.x);
    int32_t max_y = round_to_int32(r.max.y);

    if (min_x < 0) min_x = 0;
    if (min_y < 0) min_y = 0;
    if (max_x > SCREEN_WIDTH) max_x = SCREEN_WIDTH;
    if (max_y > SCREEN_HEIGHT) max_y = SCREEN_HEIGHT;

    int32_t dim_x = max_x - min_x;
    int32_t dim_y = max_y - min_y;

    for (int32_t y = min_y; y < max_y; y++)
    {
        for (int32_t x = min_x; x < max_x; x++)
        {
            buffer[y][x] = pack(color);
        }
    }

}


// initialize game data in this function
void initialize()
{
    memset(&global_game_state, 0, sizeof(GameState));

    srand(0); // @todo: initialize random seed
    global_game_state.running = false;

    push_entity(&global_game_state, Entity{}); // Let 0 be NULL entity, for something to check against
    
    int32_t player_id = push_player(&global_game_state, 200, 20);
    global_game_state.player_id = player_id;

    // Push Ball
    {
        Entity *player = get_entity(&global_game_state, player_id);

        int32_t ball_dim = 20; // px

        v2 p = player->p;
        p.y = p.y - 0.5f * ball_dim - 0.5f * player->height;

        int32_t ball_id = push_ball(&global_game_state, p);
        global_game_state.current_ball_id = ball_id;
    }

    // Push Targets
    {
        int32_t targets_count_x = 7;
        int32_t targets_count_y = 5;
        global_game_state.target_count = targets_count_x * targets_count_y;

        int32_t gap = 20; // pixels

        int32_t target_width = (SCREEN_WIDTH - (targets_count_x + 1) * gap) / targets_count_x;
        int32_t target_height = 20;

        int32_t y = gap;
        for (int32_t target_y = 0; target_y < targets_count_y; target_y++)
        {
            int32_t x = gap;
            for (int32_t target_x = 0; target_x < targets_count_x; target_x++)
            {
                v2 top_left = { float(x), float(y) };
                v2 bot_right = top_left + v2{ float(target_width), float(target_height) };

                Entity target = {};
                target.type = ENTITY_TYPE_TARGET;
                target.p = top_left + 0.5f * (bot_right - top_left);
                target.width = target_width;
                target.height = target_height;
                target.color = v4{
                    1.0f - float(target_x) / float(targets_count_x),
                    0.0f + float(target_x) / float(targets_count_x),
                    0.0f + float(target_y) / float(targets_count_y),
                    1.0f };

                push_entity(&global_game_state, target);

                x += (target_width + gap);
            }

            y += (target_height + gap);
        }
    }
}


// this function is called to update game data,
// dt - time elapsed since the previous update (in seconds)
void act(float dt)
{
    if (is_key_pressed(VK_ESCAPE))
    {
        schedule_quit_game();
    }

    // Start the game
    if (global_game_state.running == false && is_key_pressed(VK_SPACE))
    {
        global_game_state.running = true;
        Entity* ball = get_entity(&global_game_state, global_game_state.current_ball_id);
        if (ball)
        {
            float direction_x = uniform_real(-1, 1);
            ball->v = BALL_VELOCITY_COEFF * v2{ direction_x, -1.0f };
        }
    }

    // REstart the game
    if (global_game_state.running == true && global_game_state.ended == true && is_key_pressed(VK_SPACE))
    {
        global_game_state.running = false;
        global_game_state.ended = false;
        global_game_state.score = 0;
        for (uint32_t entity_index = 1; entity_index < global_game_state.entity_count; entity_index++)
        {
            Entity* entity = get_entity(&global_game_state, entity_index);
            if (entity->type == ENTITY_TYPE_TARGET) entity->dead = false;
        }
    }

    for (uint32_t entity_index = 1; entity_index < global_game_state.entity_count; entity_index++)
    {
        Entity* entity = get_entity(&global_game_state, entity_index);

        switch (entity->type)
        {
        case ENTITY_TYPE_PLAYER:
        {
            Entity* player = entity;
            ASSERT(player && player->type == ENTITY_TYPE_PLAYER);

            // VK_RIGHT, VK_LEFT, VK_UP, VK_DOWN
            {
                v2 direction = { is_key_pressed(VK_RIGHT) - is_key_pressed(VK_LEFT), 0.0f };
                v2 v = PLAYER_VELOCITY_COEFF * direction;
                v2 p = player->p + v * dt;

                if (p.x < 0.5f * player->width) p.x = 0.5f * player->width;
                if (p.x > SCREEN_WIDTH - 0.5f * player->width) p.x = SCREEN_WIDTH - 0.5f * player->width;

                player->p = p;
                player->v = v;
            }

            if (global_game_state.running == false)
            {
                if (global_game_state.current_ball_id)
                {
                    Entity* ball = get_entity(&global_game_state, global_game_state.current_ball_id);
                    
                    v2 p = player->p;
                    p.y = p.y - 0.5f * ball->height - 0.5f * player->height;

                    ball->p = p;
                }
            }
        }
        break;

        case ENTITY_TYPE_BALL:
        {
            if (global_game_state.running == true && global_game_state.ended == false)
            {
                Entity* ball = entity;

                v2 p = ball->p + ball->v * dt;
                v2 v = ball->v;

                // Compute collision with targets, walls, player, and floor
                if (p.x < 0.5f * ball->width)
                {
                    p.x = 0.5f * ball->width;
                    v.x = -ball->v.x;
                }
                if (p.x > SCREEN_WIDTH - 0.5f * ball->width)
                {
                    p.x = SCREEN_WIDTH - 0.5f * ball->width;
                    v.x = -ball->v.x;
                }
                if (p.y < 0.5f * ball->height)
                {
                    p.y = 0.5f * ball->height;
                    v.y = -ball->v.y;
                }
                if (p.y > SCREEN_HEIGHT - 0.5f * ball->height)
                {
                    p.y = SCREEN_HEIGHT - 0.5f * ball->height;
                    v = v2{ 0.0f, 0.0f };
                    // @todo: end the game here!
                    global_game_state.ended = true;
                }

                for (uint32_t test_entity_index = 1; test_entity_index < global_game_state.entity_count; test_entity_index++)
                {
                    Entity *test_entity = get_entity(&global_game_state, test_entity_index);
                    if (test_entity->dead) continue;

                    rect2 minkowski_aabb = from_center_dim(test_entity->p, v2{ float(test_entity->width), float(test_entity->height) });
                    minkowski_aabb.min.x -= 0.5f * ball->width;
                    minkowski_aabb.min.y -= 0.5f * ball->height;
                    minkowski_aabb.max.x += 0.5f * ball->width;
                    minkowski_aabb.max.y += 0.5f * ball->height;

                    bool collided = in_rectangle(minkowski_aabb, ball->p);

                    if (collided)
                    {
                        if (test_entity->type == ENTITY_TYPE_TARGET ||
                            test_entity->type == ENTITY_TYPE_PLAYER)
                        {
                            v2 vertices[4] =
                            {
                                v2{ minkowski_aabb.min.x, minkowski_aabb.min.y }, // left top
                                v2{ minkowski_aabb.max.x, minkowski_aabb.min.y }, // right top
                                v2{ minkowski_aabb.max.x, minkowski_aabb.max.y }, // right bottom
                                v2{ minkowski_aabb.min.x, minkowski_aabb.max.y }, // left bottom
                            };
                            
                            float EPS = 1;
                            auto intersect = [EPS](v2 p0, v2 p1, v2 q0, v2 q1) -> v2
                            {
                                v2 r = p1 - p0;
                                v2 s = q1 - q0;

                                float denom = r.x * s.y - r.y * s.x;
                                float nom = ((q0.x - p0.x) * s.y - (q0.y - p0.y) * s.x);

                                if (fabs(denom) < EPS && fabs(nom) < EPS) {
                                    // INTERSECTION COLLINEAR
                                    return { NAN, NAN };
                                }

                                if (fabs(denom) < EPS && fabs(nom) > EPS) {
                                    // INTERSECTION PARALLEL
                                    return { NAN, NAN };
                                }

                                float t = nom / denom;
                                v2 intersection = p0 + t * r;
                                return intersection;
                            };

                            float min_dist = length(p - ball->p);
                            v2 closest_dest = p;
                            v2 velocity_at_closest_dest = v;
                            for (int i = 0; i < 4; i++)
                            {
                                v2 a = vertices[i % ARRAY_COUNT(vertices)];
                                v2 b = vertices[(i + 1) % ARRAY_COUNT(vertices)];

                                v2 edge = (b - a);
                                v2 normal = normalized(v2{ edge.y, -edge.x });

                                if (dot(v, normal) < 0)
                                {
                                    v2 intersection = intersect(a, b, ball->p, p);

                                    rect2 small_bounds = rect2{ v2{ min(a.x, b.x) - EPS, min(a.y, b.y) - EPS }, v2{ max(a.x, b.x) + EPS, max(a.y, b.y) + EPS } };
                                    if (in_rectangle(small_bounds, intersection))
                                    {
                                        if (length(intersection - ball->p) < min_dist)
                                        {
                                            closest_dest = intersection;
                                            velocity_at_closest_dest = ball->v - 2.0f * dot(ball->v, normal) * normal;
                                        }
                                    }
                                }
                            }

                            p = closest_dest;
                            v = velocity_at_closest_dest;
                        }

                        if (test_entity->type == ENTITY_TYPE_PLAYER)
                        {
                            v.x += test_entity->v.x * 0.5f;
                        }

                        if (test_entity->type == ENTITY_TYPE_TARGET)
                        {
                            test_entity->dead = true;
                            global_game_state.score += 1;

                            if (global_game_state.score == global_game_state.target_count)
                            {
                                global_game_state.ended = true;
                            }
                        }
                    }
                }

                ball->p = p;
                ball->v = v;
            }
        }
        break;

        case ENTITY_TYPE_TARGET:
        {
            
        }
        break;
        }
    }
}

// fill buffer in this function
// uint32_t buffer[SCREEN_HEIGHT][SCREEN_WIDTH] - is an array of 32-bit colors (8 bits per R, G, B)
void draw()
{
    // clear backbuffer
    memset(buffer, 0, SCREEN_HEIGHT * SCREEN_WIDTH * sizeof(uint32_t));

    if (global_game_state.ended == true)
    {
        v4 color = v4::red;
        if (global_game_state.score == global_game_state.target_count)
        {
            color = v4::green;
        }

        int line_width = 10;
        rect2 left_line = { {0, 0}, {line_width, SCREEN_HEIGHT} };
        rect2 right_line = { {SCREEN_WIDTH - line_width, 0}, {SCREEN_WIDTH, SCREEN_HEIGHT} };
        rect2 top_line = { {line_width, 0}, {SCREEN_WIDTH - line_width, line_width} };
        rect2 bot_line = { {line_width, SCREEN_HEIGHT - line_width}, {SCREEN_WIDTH-line_width, SCREEN_HEIGHT} };
        draw_rect(left_line, color);
        draw_rect(right_line, color);
        draw_rect(top_line, color);
        draw_rect(bot_line, color);
    }

    for (uint32_t entity_index = 1; entity_index < global_game_state.entity_count; entity_index++)
    {
        Entity *entity = get_entity(&global_game_state, entity_index);
        ASSERT(entity);

        switch (entity->type)
        {
            case ENTITY_TYPE_PLAYER:
            case ENTITY_TYPE_BALL:
            case ENTITY_TYPE_TARGET:
            {
                if (!entity->dead) {
                    rect2 aabb = from_center_dim(entity->p, v2{ (float)entity->width, (float)entity->height });
                    draw_rect(aabb, entity->color);
                }
            }
            break;
        }
    }
}

// free game data in this function
void finalize()
{
}

